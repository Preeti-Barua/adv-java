package emp.services;
import java.util.List; 

import emp.models.EmpCResult;
import emp.models.Employee;


public interface EmpService {
	
	
	
//	CResult addAcc(Acc c);
//	CResult updateAcc(Acc c);
//	CResult removeAcc(int accno);
//	CResult getAccSS(int accno);
//	List<Acc> getAllDetails();
//	List<Acc> getAllDetailsOnLBalance(int balance);
	
	EmpCResult addEmp(Employee c);
	EmpCResult updateEmp(Employee c);
	EmpCResult removeEmp(int empid);
	EmpCResult getEmpSS(int empid);
	List<Employee> getAllDetails();
	List<Employee> getAllDetailsOnSalary(int salary);
	

}
