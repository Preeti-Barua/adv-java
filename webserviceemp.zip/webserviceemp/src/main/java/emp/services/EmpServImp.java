package emp.services;

import java.util.List;  
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import emp.dao.empRepository;
import emp.models.EmpCResult;
import emp.models.Employee;

@Service
public class EmpServImp  implements EmpService{

	@Autowired
	private empRepository ar;

	public EmpCResult addEmp(Employee c) {
		// TODO Auto-generated method stub
		EmpCResult c1= new EmpCResult(0,c,"failed due to user");
		try {
			ar.save(c);
			c1.setStatus(1);
			c1.setReason("success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("if if fails we think why");
		}
		return c1;
	}

	public EmpCResult updateEmp(Employee c2) {
		// TODO Auto-generated method stub
		EmpCResult c1 =new EmpCResult(0, c2, "failed due to user");
		if(ar.existsById(c2.getEmpid()))
		{
			ar.save(c2);
			c1.setStatus(1);
			c1.setReason("success");
		}
		return c1;
	}

	public EmpCResult removeEmp(int empid) {
		// TODO Auto-generated method stub
		EmpCResult c1 =new EmpCResult(0, null, "failed due to user");
		try {
			ar.deleteById(empid);
			c1.setStatus(1);
			c1.setReason("success");
		} catch (EmptyResultDataAccessException e) 
		{
			
		}
		return c1;
	}

	public EmpCResult getEmpSS(int empid) {
		// TODO Auto-generated method stub
		EmpCResult c1 =new EmpCResult(0, null, "failed due to user");
		Optional<Employee> c = ar.findById(empid);
		if(c.isPresent())
		{
			Employee x = c.get();
			c1.setReason("success");
			c1.setStatus(1);
			c1.setContent(x);
		}
		else
			System.out.println("did not get the object");	
		
		
		return c1;
	}

	public List<Employee> getAllDetails() {
		// TODO Auto-generated method stub
		return ar.findAll();	
	}

	public List<Employee> getAllDetailsOnSalary(int salary) {
		// TODO Auto-generated method stub
		return ar.f1(salary);
	}
	
	}
