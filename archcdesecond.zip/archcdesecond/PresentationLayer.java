package archcdesecond;

import java.sql.SQLException;
//501_04416_Anoop Singh is inviting you to a scheduled Zoom meeting.
//
//Topic: 501_04416_Anoop Singh's Personal Meeting Room
//
//Join Zoom Meeting
//https://us04web.zoom.us/j/7594291405?pwd=c1BHbVlYN0swR0IxM21WbTB0U0U0Zz09
//
//Meeting ID: 759 429 1405
//Passcode: 1cpP3r


public class PresentationLayer {
	
	private ServiceInterface serviceInf;
	
	public PresentationLayer() {
	
		serviceInf=new ServiceLayerImplem();
		// TODO Auto-generated constructor stub
	}

	public void start() throws SQLException {
		// TODO Auto-generated method stub
		
		insert();
		//getdetails();
	}

	private void getdetails() throws SQLException {
		// TODO Auto-generated method stub
		int eid=1;
		
		Employee e=serviceInf.getEmpdetails(eid);
		System.out.println(e);
		
	}

	private void insert() {
		// TODO Auto-generated method stub
		Employee e=new Employee(2, "Singh", 120, 1262.320);
		boolean x=false;
		x=serviceInf.addEmployee(e);
		if(x)
		{
			System.out.println("Insert Successful");
		}
		else
		{
			System.out.println("Not successfull ");
		}
		
		
	}

}
