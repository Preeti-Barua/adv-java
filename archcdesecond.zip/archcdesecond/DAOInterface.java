package archcdesecond;

import java.sql.SQLException;
import java.util.List;

public interface DAOInterface {

	void registerUserinDB(Employee emp) throws SQLException, DuplicateEmployeeException;
	
	Employee getEmpDetailsfromDB(int empid) throws SQLException;
	
	boolean updatEmpDetailinDB(Employee emp) throws SQLException;
	
	boolean deleteEmpinDB(int empid) throws SQLException;
	
	List<Employee> getAllEmployeefromDB(double salary) throws SQLException;
	
}
