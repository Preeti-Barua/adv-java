package archcdesecond;

import java.sql.SQLException;
import java.util.List;

public class ServiceLayerImplem implements ServiceInterface{
	
	private DAOInterface daointerface;

	public ServiceLayerImplem() {
		daointerface =new JDBCImplemenEmp();
	}

	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		boolean insertstat=false;
		try {
			daointerface.registerUserinDB(emp);
			insertstat=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DuplicateEmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insertstat;
	}

	@Override
	public Employee getEmpdetails(int empid) throws SQLException {
		// TODO Auto-generated method stub
		
			Employee ex=daointerface.getEmpDetailsfromDB(empid);
		
		return ex;
	}

	@Override
	public boolean updateEmpdetails(Employee emp) throws SQLException {
		// TODO Auto-generated method stub
		
		return daointerface.updatEmpDetailinDB(emp);
	}

	@Override
	public boolean removeEmp(int empid) throws SQLException {
		// TODO Auto-generated method stub
			
		return daointerface.deleteEmpinDB(empid);
	}

	@Override
	public List<Employee> getEmpBasedonSalary(double salary) throws SQLException {
		// TODO Auto-generated method stub
		return daointerface.getAllEmployeefromDB(salary);
	}
	

}
