package archcdesecond;

import java.sql.SQLException;
import java.util.List;

public interface ServiceInterface {
	
	boolean addEmployee(Employee emp);
	
	Employee getEmpdetails(int empid) throws SQLException;
	
	boolean updateEmpdetails(Employee emp) throws SQLException;
	
	boolean removeEmp(int empid) throws SQLException;

	List<Employee> getEmpBasedonSalary(double salary) throws SQLException;
	
	
	
}
