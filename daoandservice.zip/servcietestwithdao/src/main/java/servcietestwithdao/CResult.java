package servcietestwithdao;

public class CResult {
	
	private int status;
	private Acc content; // will have account details of inserted, updated, deleted
	private String reason;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Acc getContent() {
		return content;
	}
	public void setContent(Acc content) {
		this.content = content;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public CResult() {
		// TODO Auto-generated constructor stub
	}
	public CResult(int status, Acc content, String reason) {

		this.status = status;
		this.content = content;
		this.reason = reason;
	}
	
	
	
	
	

}
