package servcietestwithdao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhoASkedUsToOptimistic implements CommandLineRunner{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(WhoASkedUsToOptimistic.class, args);

	}
	
	@Autowired
	private ServiceInterface s;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		/*
		System.out.println("go step by step");
		System.out.println(s !=null );
		
		*/
		
		/*
		Acc c =new Acc(23,"X",23);
		CResult x = s.addAcc(c);
		System.out.println(x.getStatus());

		*/
		
		
		/*
		
		Acc c =new Acc(22333,"Y",233);
		CResult x = s.updateAcc(c);
		System.out.println(x.getStatus());
		
		*/
		
		int balance = 233;
		List<Acc> c =s.getAllDetailsOnLBalance(balance);
		for(Acc y:c)
		{
			System.out.println(y.getBalance());
		}
		

		
		
	}

}
