package servcietestwithdao;

import java.util.List;

//welcome to the hardest thing
//in a project
public interface ServiceInterface {
	
	CResult addAcc(Acc c);
	CResult updateAcc(Acc c);
	CResult removeAcc(int accno);
	CResult getAccSS(int accno);
	List<Acc> getAllDetails();
	List<Acc> getAllDetailsOnLBalance(int balance);
	
	


}
