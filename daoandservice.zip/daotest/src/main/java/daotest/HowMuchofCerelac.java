package daotest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.dao.EmptyResultDataAccessException;

@SpringBootApplication
public class HowMuchofCerelac implements CommandLineRunner{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(HowMuchofCerelac.class, args);

		
	}
	
	@Autowired  //tells spring  hey wire it.
	private AccRepository ar;
	
	
	

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
System.out.println("other people cannot tell when do poc");
/*		

	Acc c =new Acc(11,"Aa",2001);
	ar.save(c);
	
	*/

/*

int accnopk =3;
Optional<Acc> c = ar.findById(accnopk);
if(c.isPresent())
{
	Acc x = c.get();
	System.out.println(c);
}
else
	System.out.println("did not get the object");
*/


/*
int accnopk =44;

	try {
		ar.deleteById(accnopk);
	} catch (EmptyResultDataAccessException e) {
		// TODO Auto-generated catch block
		System.out.println("no accnofound ");//details can be got
		//by using printSTackTrace...
		
	}
	
	*/


/*
	List<Acc> l = ar.findAll();
	for(Acc x:l)
	{
		System.out.println(x.getAcno());
	}
	
	*/


int bal=400;
List<Acc> l = ar.f1(bal);
for(Acc m : l)
{
	System.out.println(m.getBalance());
}






	
	
	




		
	}

}
