package daotest;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Acc {
	
	@Id
	private int acno;
	private String name;
	private int balance;
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Acc() {
		// TODO Auto-generated constructor stub
	}
	public Acc(int acno, String name, int balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Acc [acno=" + acno + ", name=" + name + ", balance=" + balance + "]";
	}
	
	
	

}
