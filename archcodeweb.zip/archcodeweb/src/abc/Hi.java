package abc;

public class Hi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(123);

	}

}
