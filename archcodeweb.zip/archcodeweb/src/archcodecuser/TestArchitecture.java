package archcodecuser;

public class TestArchitecture {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Presentation p =new Presentation();
		p.startTheApp();
		/*
		 
		
		once you understand this program come up with a logic for
		Emp  empno,mobileno ,deptid are all ints
		empname is a string, create a class
		demonsrate insert , single select and update , delete, multi select based on deptid
		
		*/
		

	}

}
