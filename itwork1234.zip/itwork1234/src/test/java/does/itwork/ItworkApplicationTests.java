package does.itwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
