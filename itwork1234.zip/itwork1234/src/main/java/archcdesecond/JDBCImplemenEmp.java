package archcdesecond;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class JDBCImplemenEmp implements DAOInterface{
	
	@Autowired
	private JdbcTemplate j;
			
	public JDBCImplemenEmp() {
		System.out.println("JDBC imp Created");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void registerUserinDB(Employee emp) throws DuplicateEmployeeException {
		// TODO Auto-generated method stub
		
		String sql="insert into employee values(?,?,?,?)";
		Object params[]= {emp.getEmpid(),emp.getEmpname(),emp.getDeptid(),emp.getSalary()};
		
		try {
			int x=j.update(sql, params);
			
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DuplicateEmployeeException x=new DuplicateEmployeeException("failed due to prim key vio");
			throw x;
		}
		
		
	}

	@Override
	public Employee getEmpDetailsfromDB(int empid)  {
		// TODO Auto-generated method stub
		
		Employee e=null;
		
		String sql="select empid,empname,deptid,salary from employee where empid=?";
		Object parameters[]= {empid};
		BeanPropertyRowMapper<Employee> x=BeanPropertyRowMapper.newInstance(Employee.class);
		try {
			e=j.queryForObject(sql, parameters, x);
		} catch (DataAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("Where coniditon failed");
			e=new Employee(0, "", 0, 0);
		}
		return e;
	}

	@Override
	public boolean updatEmpDetailinDB(Employee emp)  {
		// TODO Auto-generated method stub
		boolean updated=false;
		String sql="update employee set empname=?,deptid=?,salary=? where empid=?";
		Object x[]= {emp.getEmpname(),emp.getDeptid(),emp.getSalary(),emp.getEmpid()};
		int z= j.update(sql, x);
		if(z>0)
		{
			updated=true;
		}
		return updated;
	}

	@Override
	public boolean deleteEmpinDB(int empid) {
		// TODO Auto-generated method stub
		boolean deleted=false;
		String sql="delete from employee where empid=?";
		Object x[]= {empid};
		int z=j.update(sql, x);
		if(z>0)
		{
			deleted=true;
		}
		return deleted;
	}

	@Override
	public List<Employee> getAllEmployeefromDB(double salary) {
		// TODO Auto-generated method stub
		List<Employee> e;
		String str="select empid,empname,deptid,salary from employee where salary>?";
		Object p[]= {salary};
		BeanPropertyRowMapper<Employee> n=BeanPropertyRowMapper.newInstance(Employee.class);
		try {
			e=j.query(str, p, n);
		} catch (DataAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("Failed where condition");
			e=new ArrayList<>();
		}
		return e;
	}
	
	

}
