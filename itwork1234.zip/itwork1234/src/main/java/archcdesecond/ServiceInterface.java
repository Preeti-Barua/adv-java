package archcdesecond;

import java.sql.SQLException;
import java.util.List;

public interface ServiceInterface {
	
	boolean addEmployee(Employee emp);
	
	Employee getEmpdetails(int empid) ; 
	
	boolean updateEmpdetails(Employee emp) ;
	
	boolean removeEmp(int empid) ;

	List<Employee> getEmpBasedonSalary(double salary) ;
	
	
	
}
