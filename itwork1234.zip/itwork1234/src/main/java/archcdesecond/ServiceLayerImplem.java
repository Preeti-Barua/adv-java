package archcdesecond;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ServiceLayerImplem implements ServiceInterface{
	@Autowired
	private DAOInterface daointerface;

	

	
	
	
	
public ServiceLayerImplem()  {
		
		System.out.println("service object created");
		// TODO Auto-generated constructor stub
		//daoInterface = new ListBasedMockDAOImplementation();
		
		//daoInterface = new MapBasedMockDAOImplementation();
		
		//daoInterface = new JDBCImplemntation();

		
	}

	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		boolean insertstat=false;
		try {
			daointerface.registerUserinDB(emp);
			insertstat=true;
		}  catch (DuplicateEmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insertstat;
	}

	@Override
	public Employee getEmpdetails(int empid) {
		// TODO Auto-generated method stub
		
			Employee ex=daointerface.getEmpDetailsfromDB(empid);
		
		return ex;
	}

	@Override
	public boolean updateEmpdetails(Employee emp) {
		// TODO Auto-generated method stub
		
		return daointerface.updatEmpDetailinDB(emp);
	}

	@Override
	public boolean removeEmp(int empid) {
		// TODO Auto-generated method stub
			
		return daointerface.deleteEmpinDB(empid);
	}

	@Override
	public List<Employee> getEmpBasedonSalary(double salary) {
		// TODO Auto-generated method stub
		return daointerface.getAllEmployeefromDB(salary);
	}
	

}
