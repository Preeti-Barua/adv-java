package archcdesecond;

public class DuplicateEmployeeException extends Exception {
	
	public DuplicateEmployeeException(String str)
	{
		super(str);
	}

}
