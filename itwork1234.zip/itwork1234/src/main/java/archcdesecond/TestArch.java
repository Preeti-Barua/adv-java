package archcdesecond;

import java.sql.SQLException;

public class TestArch {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		PresentationLayer p=new PresentationLayer();
		p.start();

	}

}
