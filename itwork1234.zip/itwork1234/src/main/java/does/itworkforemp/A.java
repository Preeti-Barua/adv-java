package does.itworkforemp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import archcdesecond.ServiceInterface;
import archcdesecond.Employee;

@RestController //sign our controller functions
//wil no longer return response, it will return
//just data..

public class A {
	
	@Autowired
	private ServiceInterface serinf;
	
	@PutMapping("/ru")
	boolean regEmp(@RequestBody Employee e)
	{	
		boolean res=serinf.addEmployee(e);
		return res;
		
	}
	
	@GetMapping("/ssu")
	Employee singleselecus(@RequestParam("eid") int empid)
	{
		Employee e=serinf.getEmpdetails(empid);
		return e;
		
	}
	
	@PostMapping("/uud")
	boolean updateUserDetail(@RequestBody Employee e)
	{
		boolean z=serinf.updateEmpdetails(e);
		return z;
		
	}
	
	@DeleteMapping("/dr")
	boolean deleteUserfromDB(@RequestParam("eid") int empid)
	{
		return serinf.removeEmp(empid);
		
	}
	
	@PostMapping("/msu")
	List<Employee> showEMPS(@RequestParam("y") double salary)
	{
		List<Employee> e=new ArrayList<Employee>();
		Employee e1=new Employee(1, "A", 12, 521.2+salary);
		Employee e2=new Employee(2, "B", 12, 521.2+salary);
		Employee e3=new Employee(3, "C", 12, 521.2+salary);
		
		e.add(e1);
		e.add(e2);
		e.add(e3);
		if(e.size() >0)
		{
			System.out.println("Success");
		}
		return e;
		
	}
	@PutMapping("/au")
	boolean registerEmp(@RequestBody Employee e1)
	{
		System.out.println("EMP REGISTERED");
		if(e1.getEmpname().equalsIgnoreCase("anoop"))
			return true;
		else
			return false;
		
		
	}
	
	
	
	@PostMapping("/uu")
	boolean updateUser(@RequestBody Employee e)
	{
		
		System.out.println("update user");
		if(e.getEmpname().equals("abc"))
			return true;
		else
			return false;
		
		
	}
	
	@DeleteMapping("/du")
	boolean removeUser(@RequestParam("x") String username)
	{
		System.out.println("delete user");
		if(username.equalsIgnoreCase("Anoop"))
			return true;
		else
			return false;
		
		
	}
	
	
	
	
	
	
	
	

	

	
	
	@PostMapping("/pw")
	public Employee f2()
	{
		Employee e=new Employee(1, "Anoop", 24, 1234.5);
		return e;
		
	}
	

}
