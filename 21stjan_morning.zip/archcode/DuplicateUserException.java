package archcode;

public class DuplicateUserException extends Exception {

	public DuplicateUserException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
