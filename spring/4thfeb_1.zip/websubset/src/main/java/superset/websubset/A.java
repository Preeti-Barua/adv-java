package superset.websubset;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class A {
	
	@PostMapping("/ijk")
	public String f1(@ModelAttribute  Rct  x ,Map<String, Object> m)
	{
		m.put("k4",x.getL() *x.getB());
		System.out.println("value of x "+ x.getL());
		return "hi.jsp";
		
	}
	
	
	
	
	
	@PostMapping("/abc")
	public String f1(@RequestParam("q")  int x ,Map<String, Object> m)
	{
		m.put("k1",x*3);
		System.out.println("value of x "+ x);
		return "hi.jsp";
		
	}
	
	@GetMapping("/def")
	public String f2(@RequestParam("q")  int x ,Map<String, Object> m)
	{
		List<Integer> l =new ArrayList<Integer>();
		l.add(x*2);
		l.add(x *3);
		l.add(x *4);
		m.put("k2",l);
		System.out.println("value of x "+ x);
		return "hi.jsp";
		
	}
	
	@PostMapping("/ghi")
	public  String f3(Map<String, Object> m)
	{
		Rct r =new Rct(12,13);
		m.put("k3",r);
		return "hi.jsp";
		
		
	}
	
	
	

}
