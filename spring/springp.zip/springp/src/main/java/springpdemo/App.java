package springpdemo;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
public class App {
	
	public static void main(String[] args) {
		// pom.xml file kaha h maven project ki? shit
		
		
	  BeanFactory factory=new XmlBeanFactory(new FileSystemResource("spring.xml"));
	 //  ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("spring.xml");
	 //  Mist m=c.getBean(Mist.class);
	   // m.code();
	   Mist obj=(Mist)factory.getBean("Mist.class");
	   obj.code();
	
	   
	   
		
	}
	
	

}

