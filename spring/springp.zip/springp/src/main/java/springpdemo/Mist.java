package springpdemo;

public class Mist {
	
	public void code()
	{
		System.out.println("I am coding");
	}

	
	public Mist()
	{
		System.out.println("Mist obj created");
	}
}
