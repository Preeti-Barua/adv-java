package jdbcritual;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Ctry x =new Ctry(45,"mysore","vnagar");
		
		
		try {
			String url = "jdbc:mysql://localhost:3309/test";
			String userid = "root";
			String password = "1234";
			 Connection con = DriverManager.getConnection(url, userid, password);
		
			 String tql =
					 "insert into country(pincode,area,city) values (?,?,?)";
			 
			 PreparedStatement ps = con.prepareStatement(tql);
			
			 ps.setInt(1, x.getPc());
			 ps.setString(2,x.getAn());
			 ps.setString(3, x.getCn());
			 
			 int ra = ps.executeUpdate();
			 
			 
			 ps.close(); //stupid things any how we will do it
			 con.close();//stupid things any how we will do  it
			 
			 System.out.println("123"); //if you reach this line
			 //it means no exception occured. no exception occured
			 //means things suceeded..
			 
			 
			 	 
			 
			 
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
