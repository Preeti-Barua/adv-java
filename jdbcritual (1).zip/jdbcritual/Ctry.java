package jdbcritual;

public class Ctry {
	
	private int pc;
	private String cn, an;
	public int getPc() {
		return pc;
	}
	public void setPc(int pc) {
		this.pc = pc;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getAn() {
		return an;
	}
	public void setAn(String an) {
		this.an = an;
	}
	public Ctry(int pc, String cn, String an) {
		
		this.pc = pc;
		this.cn = cn;
		this.an = an;
	}
	public Ctry() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
