package jdbcritual;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MultiSelect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Ctry> l =new ArrayList<Ctry>();
 		String cn ="bombay";
		Ctry x =null;
		System.out.println("before " + l.size());
		
		try {
			String url = "jdbc:mysql://localhost:3309/test";
			String userid = "root";
			String password = "1234";
			 Connection con = DriverManager.getConnection(url, userid, password);
		
			 String tql =
					 " select pincode, area, city from country where city =?";
			 
			 PreparedStatement ps = con.prepareStatement(tql);
			
			 
			 ps.setString(1,cn);
			 
			 ResultSet ra = ps.executeQuery();
			 
			 while(ra.next())
			 {
				
				  int pincode = ra.getInt("pincode");
				 String aream = ra.getString("area");
				 String cityname=ra.getString("city");
				 x=new Ctry(pincode,cityname,aream) ;
				 l.add(x);
				 
				 
			 	}
			
			  
			 if(l.size() > 0)
			 {
				 String contents="";
				 for(Ctry y: l)
				 {
					  contents +="\n " + y.getPc() +
							 " " + y.getAn() +
							 "  " + y.getCn();
					
					 
				 }
				 System.out.println(contents);
				 
				 
			 }
			 else
				 System.out.println("no rows were found");

			 
			 ps.close(); //stupid things any how we will do it
			 con.close();//stupid things any how we will do  it
			 
			 System.out.println("456"); //if you reach this line
			 //it means no exception occured. no exception occured
			 //means things suceeded..
			 
			 
			 	 
			 
			 
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
