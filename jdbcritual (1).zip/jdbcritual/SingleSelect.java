package jdbcritual;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SingleSelect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int pincode =567;
		Ctry x =new Ctry();
		
		
		try {
			String url = "jdbc:mysql://localhost:3309/test";
			String userid = "root";
			String password = "1234";
			 Connection con = DriverManager.getConnection(url, userid, password);
		
			 String tql =
					 " select pincode, area, city from country where pincode =?";
			 
			 PreparedStatement ps = con.prepareStatement(tql);
			
			 
			 ps.setInt(1,pincode);
			 
			 ResultSet ra = ps.executeQuery();
			 
			 if(ra.next())
			 {
				 System.out.println("found");
				  pincode = ra.getInt("pincode");
				 String aream = ra.getString("area");
				 String cityname=ra.getString("city");
				 x.setPc(pincode);
				 x.setCn(cityname);
				 x.setAn(aream);
				 
				 String contents ="\n pincode is" + x.getPc() +
						 "\n area name " + x.getAn() +
						 "\n city name " + x.getCn();
				 
				 System.out.println(contents);
				 
				 
			 	}
			 else
			 {
				 System.out.println("not found");
				 
			 }
			  
			 ps.close(); //stupid things any how we will do it
			 con.close();//stupid things any how we will do  it
			 
			 System.out.println("456"); //if you reach this line
			 //it means no exception occured. no exception occured
			 //means things suceeded..
			 
			 
			 	 
			 
			 
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
