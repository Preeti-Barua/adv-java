package com.howtodoinjava.app.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	
	
	@RequestMapping("/stepbystep")
	public String whocares()
	{
		System.out.println("are we reaching the function");
		return "second.html";
		
	}
	
	
	//localhost:8080/pw -enter
	//if somebody makes a reuest to server
	// in get mode and string is pw
	@GetMapping("/pw")
	public String f1()
	{
		System.out.println(4);
		return "junk.jsp";
		
	}
	

	@RequestMapping("/")
	public String office(Map<String, Object> model) {
		
		//imagine we get an Emp object from the service layer
		
		// we want to show emp object in the JSP
		
		// emp object must be put in the model.
		
		//in the jsp we have to read it..
		
		//this model is put on the request notice baord..
		model.put("message", "abc");//this data spring
		//will ensure is avaialbel for the view...
		return "index"; //you can be sure that this is some page...
		
		//that is respone page...
	}
	
	@RequestMapping("/next")
	public String next(Map<String, Object> model) {
		model.put("message", "You are in new page !!");
		return "next";
	}

}