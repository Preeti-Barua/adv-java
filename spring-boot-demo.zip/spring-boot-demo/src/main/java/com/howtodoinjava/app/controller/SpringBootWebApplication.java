package com.howtodoinjava.app.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class SpringBootWebApplication  {


	public static void main(String[] args) throws Exception {
		
		System.out.println(1);
		SpringApplication.run(SpringBootWebApplication.class, args);
	}
}