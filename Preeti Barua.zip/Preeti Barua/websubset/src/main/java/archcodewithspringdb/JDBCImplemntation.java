package archcodewithspringdb;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;



@Repository("archcodewithspring")
public class JDBCImplemntation implements DAOInterface {
	

	
	@Autowired
	private JdbcTemplate t;
	
	public void f1()
	{
		System.out.println("t is "  + (t!=null));
		
	}
	
	
	
	
	

	@Override
	public void registerUserInDb(CUser user) throws DuplicateUserException {
		
		String sql ="insert into user( username,password,email,pincode) values (?,?,?,?)";
		Object params[]= { user.getUsername(),user.getPassword(),user.getEmail(),user.getPincode()};
		try {
			int ra = t.update(sql,params);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DuplicateUserException d =new DuplicateUserException("ok failed");
			throw d;

		}
		
		
		
		}
		
		
		



	@Override
	public CUser getUserDetailsFromDb(String userid) {
		
		
		CUser user=null;
		String sql ="select username,password, email, pincode from user where username=?";
		Object params[]= {userid};
		BeanPropertyRowMapper<CUser> rw = BeanPropertyRowMapper.newInstance(CUser.class);
		try {
			user = t.queryForObject(sql, params,rw);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			System.out.println("where codntion failed exception has ocured");
			user =new CUser("","","",0);
		}
		return user;

	}

	@Override
	public boolean updateDetailsInDb(CUser user) {
		// TODO Auto-generated method stub
				boolean updated = false;
		String sql ="update user set password =?,email=?,pincode=?  where username=?";
		Object params[]= {user.getPassword(),user.getEmail(),user.getPincode(),user.getUsername()};
		int ra = t.update(sql,params);
		if( ra > 0)
			updated=true;
		return updated;
			}

	@Override
	public boolean removeUserInDb(String userid) {
		// TODO Auto-generated method stub
		boolean updated = false;
		String sql ="delete from user where username=?";
		Object params[]= {userid };
		int ra = t.update(sql,params);
		if( ra > 0)
			updated=true;
		return updated;
			}
	

	@Override
	public List<CUser> getAllUsersFromDBBasedonPincode(int pincode) {
		// TODO Auto-generated method stub
		List<CUser> l ;
		String sql ="select username,password, email, pincode from user  where pincode=?";
		Object params[]= {pincode};
		BeanPropertyRowMapper<CUser> rw = BeanPropertyRowMapper.newInstance(CUser.class);
		try {
			l = t.query(sql, params,rw);//in case you get multiple rows..
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			System.out.println("where codntion failed exception has ocured");
			l=new ArrayList<>();
		}
		return l;
	}






	@Override
	public CUser searchUserInDb(String username, String password) 
	{
		
		CUser user = null;
		
		boolean update= false;
		String sql ="select username,password,email,pincode from user where username =? and password= ?";
		
		Object params[] = {username,password};
		
		BeanPropertyRowMapper<CUser> rw = BeanPropertyRowMapper.newInstance(CUser.class);
		
		try {
			user =t.queryForObject(sql, params,rw);
			user.toString();
		}catch(DataAccessException e)
		{
			System.out.println("where conditon failed exception has occured");
			user = new CUser("","","",0);
		}
		
		return user;
	}


	

}
