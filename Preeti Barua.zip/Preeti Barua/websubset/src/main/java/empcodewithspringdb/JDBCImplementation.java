package empcodewithspringdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;



@Repository
public  class JDBCImplementation implements DAOIn 
{

/*	private Connection con;
	
	public JDBCImplemntation()
	{
	
		String driverName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/test";
		String userid="root";
		String password="root";
		try 
		{
			Class.forName(driverName);
			con =DriverManager.getConnection(url,userid,password);
			//con.setAutoCommit(false);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
	
		
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("shortcut is to hell only");
			
			
		}
		
	}
	*/

	

	
	@Autowired
	private JdbcTemplate t;
	
	public void f1()
	{
		System.out.println("t is "  + (t!=null));
		
	}
	@Override
	public void registerUserInDb(EUser user) throws DuplicateUserException 
	{
		// TODO Auto-generated method stub
		PreparedStatement st=null ;
		String sql ="insert into employee( empid,empname,deptid) values (?,?,?)";
		Object params[]= { user.getEmpno(),user.getEmpname(),user.getDeptid()};
		try 
		{
			int ra = t.update(sql,params);
			
		} 
		catch (DataAccessException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			DuplicateUserException d =new DuplicateUserException("ok failed");
			throw d;

		}
		
		
	}
	@Override
	public boolean updateDetailsInDb(EUser user)
	{
		// TODO Auto-generated method stub
		boolean updated = false;
		
		String sql ="update  employee set empname =?,deptid=?  where empid=?";
		//count the number of ? marks... so many question we have to fill up
		//question makr no is left to right
		Object params[]= {user.getEmpname(),user.getDeptid(),user.getEmpno()};
		int ra = t.update(sql,params);
		if( ra > 0)
			updated=true;
		return updated;
			
		
		
	}

	@Override
	public EUser getUserDetailsFromDb(int eno) 
	{
		// TODO Auto-generated method stub
		EUser user=null;
		
		String sql ="select empid,empname,deptid from employee where empid=?";
		Object params[]= {eno};
		BeanPropertyRowMapper<EUser> rw = BeanPropertyRowMapper.newInstance(EUser.class);
		try 
		{
			user = t.queryForObject(sql, params,rw);
		} 
		catch (DataAccessException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("where codntion failed exception has ocured");
			user =new EUser(0,"",0);
		}
		return user;
	}

	@Override
	public boolean removeUserInDb(String enam) 
	{
		// TODO Auto-generated method stub
		boolean updated = false;
		String sql ="delete from employee where empname=?";
		Object params[]= {enam };
		int ra = t.update(sql,params);
		if( ra > 0)
			updated=true;
		return updated;
	
	}
	@Override
	public List<EUser> getAllUsersFromDBBasedondeptid(int deptid) 
	{
		List<EUser> l;
		
		String sql ="select empid,empname,deptid from employee where deptid=?";
		//count the number of ? marks... so many question we have to fill up
		//question makr no is left to right
		
		Object params[]= {deptid};
		BeanPropertyRowMapper<EUser> rw = BeanPropertyRowMapper.newInstance(EUser.class);
		try 
		{
			l = t.query(sql, params,rw);//in case you get multiple rows..
		} 
		catch (DataAccessException e) 
		{
			// TODO Auto-generated catch block
			System.out.println("where codntion failed exception has ocured");
			l=new ArrayList<>();
		}
		return l;
	}

}
