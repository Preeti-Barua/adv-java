package empcodewithspringdb;

public class EUser 
{
	private int empno,deptid;
	private String empname;
	

	public EUser()
	{
	
	}
	public EUser(int empno,String empname, int deptid) 
	{
		this.empno = empno;
		this.empname = empname;
		this.deptid = deptid;
		
	}
	public int getEmpno() 
	{
		return empno;
	}
	public void setEmpno(int empno) 
	{
		this.empno = empno;
	}
	public String getEmpname() 
	{
		return empname;
	}
	public void setEmpname(String empname) 
	{
		this.empname = empname;
	}
	public int getDeptid() 
	{
		return deptid;
	}
	public void setDeptid(int deptid) 
	{
		this.deptid = deptid;
	}
	
	
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EUser [empno=");
		builder.append(empno);
		builder.append(", empname=");
		builder.append(empname);
		builder.append(", deptid=");
		builder.append(deptid);
		builder.append("]");
		return builder.toString();
	}
	
	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + empno;
		return result;
	}
	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj) 
		{
			return true;
		}
		if (!(obj instanceof EUser)) 
		{
			return false;
		}
		EUser other = (EUser) obj;
		if (empno != other.empno) 
		{
			return false;
		}
		return true;
	}
	
	
	
	
	
	
	
/*	public int hashCode() 
	{
		
		return empname.hashCode();
	}
	
	
	public boolean equals(Object obj) 
	{
		if (this == obj) 
		{
			return true;
		}
		if (obj == null) 
		{
			return false;
		}
		if (!(obj instanceof EUser)) 
		{
			return false;
		}
		EUser other = (EUser) obj;
		
		if (empname == null) 
		{
			if (other.empname != null) 
			{
				return false;
			}
		} 
		else if (!empname.equals(other.empname)) 
		{
			return false;
		}
		return true;
	}
*/
	
}