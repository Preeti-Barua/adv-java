package empcodewithspringdb;

import java.util.ArrayList;
import java.util.List;



public class ListBasedMockDAOImplementation implements DAOIn 
{
	private List<EUser>  users ;
	
	public ListBasedMockDAOImplementation()
	{
		users=new ArrayList<>();
		users.add(new EUser(15,"Guddu",111));
		users.add(new EUser(6,"Loral",122));
		users.add(new EUser(7,"Jenny",111));
	}
	
	
	@Override
	public void registerUserInDb(EUser user) throws DuplicateUserException 
	{
		// TODO Auto-generated method stub
		int position = users.indexOf(user);
		if (position != -1)
		{  
			throw new DuplicateUserException("duplicate User found");
			
		}
		users.add(user);
	}

	@Override
	public boolean updateDetailsInDb(EUser user) 
	{
		// TODO Auto-generated method stub
		
		boolean updatedStatus = false;
		int pos = users.indexOf(user);
		if(pos != -1)
		{
			//think why are we doing this.
			EUser empFromList = users.get(pos);
			empFromList.setEmpno(user.getEmpno());
			empFromList.setEmpname(user.getEmpname());
			empFromList.setDeptid(user.getDeptid());
			updatedStatus = true;
				
		}
		
		return updatedStatus;
	}

	@Override
	public EUser getUserDetailsFromDb(int eno) 
	{
		// TODO Auto-generated method stub
		//EUser userToFind = new EUser(eno,"",0);//think why we did not pass other parameters.
		EUser userToFind = new EUser(eno,"",0);
		int pos = users.indexOf(userToFind);
		System.out.println(pos);
		if(pos != -1)
		{
			userToFind = users.get(pos);
			
		}
		System.out.println(userToFind);
		return userToFind;
		
	}

	@Override
	public boolean removeUserInDb(String enam) 
	{
		// TODO Auto-generated method stub
		boolean deleted = false;
		EUser userToFind = new EUser(0,enam,0);//think why we did not pass other parameters.
		int pos = users.indexOf(userToFind);
		if(pos != -1)
		{
			users.remove(pos);
			deleted  =true;
			
		}
		return deleted;
	}


	public List<EUser> getAllUsersFromDBBasedondeptid(int deptid) 
	{
		// TODO Auto-generated method stub
		List<EUser> cusers =new ArrayList<EUser>(); //if i change the refernce to users what will happen think
		for(EUser user: users)
		{
			if(user.getDeptid() == deptid) //think why == was used and not .equals.
			{
				cusers.add(user);
			}
			
		}
		
		return cusers;
	}


	

}
