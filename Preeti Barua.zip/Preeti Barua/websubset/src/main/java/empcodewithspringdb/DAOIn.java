package empcodewithspringdb;

import java.util.List;

public interface DAOIn 
{

	void registerUserInDb(EUser user) throws DuplicateUserException;;

	boolean updateDetailsInDb(EUser user);

	boolean removeUserInDb(String enam);
	
	List<EUser> getAllUsersFromDBBasedondeptid(int deptid);

	EUser getUserDetailsFromDb(int eno);



}
