package empcodewithspringdb;

import java.util.List;

public interface ServiceIn 
{



	boolean removeUser(String enam);

	boolean updateUserDetails(EUser user);

	boolean registerUser(EUser user);

	List<EUser> getUsersBasedOndeptid(int deptid);

	EUser getUserDetails(int eno);

}
