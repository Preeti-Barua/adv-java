package empcodewithspringdb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapBasedMockDAOImplementation implements DAOIn 
{

	private Map<Integer,EUser> users ;
	
	public MapBasedMockDAOImplementation()
	{
		
		users=new HashMap<>();
		EUser user =new EUser(10,"B",111);
		users.put(user.getEmpno(), user);
		user =new EUser(11,"Ex",112); //why are we writing user = and not Cuser user = ?
		users.put(user.getEmpno(), user);
		user =new EUser(7,"Geg",112);		
		users.put(user.getEmpno(), user);
		
	}
	
	
	

	@Override
	public void registerUserInDb(EUser user) throws DuplicateUserException 
	{
		// TODO Auto-generated method stub
		user = users.get(user.getEmpname());
		
		if (user != null)//if key is present, that means it is a duplicate userid.
		{  
			throw new DuplicateUserException("duplicate User found");
			
		}
		users.put(user.getEmpno(),user);
		

	}

	@Override
	public boolean updateDetailsInDb(EUser user) 
	{
		// TODO Auto-generated method stub
		boolean updatedStatus = false;
		EUser eUser = users.get(user.getEmpno()); //think why we created a new reference cUser here
		//and not used user = users.get(user.getUsername()
		
		if(eUser != null)
		{
			//think why are we doing this.
			eUser.setEmpno(user.getEmpno());
			eUser.setEmpname(user.getEmpname());
			eUser.setDeptid(user.getDeptid());
			updatedStatus = true;
			
		}
		return updatedStatus;
	}

	@Override
	public EUser getUserDetailsFromDb(int eno) 
	{
		// TODO Auto-generated method stub
		EUser userToFind = null;//think why we did not pass other parameters.
		userToFind = users.get(eno);
		if (userToFind == null)
		{  
			userToFind = new EUser(eno,"",0);
		}
		return userToFind;
		
	}


	@Override
	public boolean removeUserInDb(String enam) 
	{
		// TODO Auto-generated method stub
		boolean deleted = false;
		EUser eUser = users.remove(enam); //think why we created a new reference cUser here
		//and not used user = users.get(user.getUsername()
		
		if(eUser != null)
		{
				deleted = true;
		
		}
		return deleted;
	
	}

	@Override
	public List<EUser> getAllUsersFromDBBasedondeptid(int deptid) 
	{
		// TODO Auto-generated method stub
		List<EUser> eusers = new ArrayList<>();
		for(EUser user: users.values())  //find out what is return type of user.values functions
		{
			if(user.getDeptid() == deptid) //think why == was used and not .equals.
			{
				eusers.add(user);
			}
			
		}
		
		return eusers;
		
	}




}
