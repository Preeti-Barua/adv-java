package empcodewithspringdb;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class ServiceImp implements ServiceIn 
{
	@Autowired
	private DAOIn daoInterface;
	
	
	
/*	public ServiceImplementation() throws ShowStopperException 
	{
		//daoInterface = new ListBasedMockDAOImplementation();
		
		//daoInterface = new MapBasedMockDAOImplementation();

		//daoInterface = new JDBCImplemntation();
		System.out.println("service object created ");
		
	}*/
	
	

	@Override
	public boolean removeUser(String enam) {
		// TODO Auto-generated method stub
		return daoInterface.removeUserInDb(enam);
	}

	
	@Override
	public EUser getUserDetails(int eno) 
	{
		// TODO Auto-generated method stub
		EUser user = daoInterface.getUserDetailsFromDb(eno);
		return user;
	}

	@Override
	public boolean updateUserDetails(EUser user) 
	{
		// TODO Auto-generated method stub
		
		return  daoInterface.updateDetailsInDb(user);
	}

	
	
	@Override
	public boolean registerUser(EUser user) 
	{
		// TODO Auto-generated method stub
		boolean insertStatus = false;		
		try 
		{
			daoInterface.registerUserInDb(user);
			insertStatus=true;
		} 
		catch (DuplicateUserException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insertStatus;
		
	}



	@Override
	public List<EUser> getUsersBasedOndeptid(int deptid) 
	{
		// TODO Auto-generated method stub
		return daoInterface.getAllUsersFromDBBasedondeptid(deptid);
	}

}
