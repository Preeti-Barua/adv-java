package superset.websubset;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mariadb.jdbc.Driver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import archcodewithspringdb.CUser;
import archcodewithspringdb.ServiceInf;
import empcodewithspringdb.EUser;
import empcodewithspringdb.ServiceIn;


@Controller
public class A {
	
	@Autowired
	private ServiceInf serviceInf;
	@Autowired
	private ServiceIn serviceIn;
	
	@Bean
	public JdbcTemplate f1()
	{
		JdbcTemplate x =null;
		
		Driver d =new Driver();
		SimpleDriverDataSource s =new SimpleDriverDataSource(d,"jdbc:mysql://localhost:3306/test","root","root");
		x =new JdbcTemplate(s); //green and red wired
		return x;
		
		
	}
	
	@PostMapping("/lasts")
	public String goemp(@RequestParam("empno") String empno ,
			@RequestParam("empname") String empname ,
			@RequestParam("deptid") String deptid ,
			@RequestParam("por")  String x,Map<String, Object> m)
	{
		String s ="/emp.jsp";
		
		if(x.equals("getdetails"))
		{
			int pc = Integer.parseInt(empno);
			EUser user = serviceIn.getUserDetails(pc);
			
			if(user.getDeptid() ==0)
			{
				m.put("k1", "Employee details not found");
				
			}
			else
			{
				m.put("k1", "Employee details found");
				m.put("existingdetails", user);
			}
			
			
			
		}
		else if(x.equals("update"))
		{
			
			EUser user =new EUser(Integer.parseInt(empno), empname, Integer.parseInt(deptid));
			boolean y = serviceIn.updateUserDetails(user);
			System.out.println("value of y is" + y);
			if(y)
			{
				m.put("k1","details updated");
			}
			else
			{
				m.put("k1","details not updated");
			}
			user.setEmpno(0);
			user.setEmpname("");
			user.setDeptid(0);
			m.put("existingdetails",user );

			
			
		}
		else if(x.equals("insert"))
		{
			
			
			EUser user =new EUser(Integer.parseInt(empno), empname,Integer.parseInt(deptid));
			boolean y = serviceIn.registerUser(user);
			System.out.println("value of y is" + y);
			if(y)
			{
				m.put("k1","inserted");
			}
			else
			{
				m.put("k1","Employee details not added");
			}
			user =new EUser(0, "", 0);
			
			m.put("existingdetails",user );
			
			
			
		}
		
		else if(x.equals("get employee on deptid"))
		{
			
			int pc = Integer.parseInt(deptid);
			List<EUser> users = serviceIn.getUsersBasedOndeptid(pc);
			if(users.size() ==0)
				m.put("k1", "No Employee found in the Deptid");
			else
				m.put("k1", "Employee found in Deptid");
			 m.put("ms", users);
			
			
			
		}
		
		else if(x.equals("delete"))
		{
			
		
			boolean y = serviceIn.removeUser(empname);
			System.out.println("value of y is" + y);
			if(y)
			{
				m.put("k1","details Removed");
			}
			else
			{
				m.put("k1","details not Removed");
			}
			

		}
	
		return s;

		
	}
	

	
	@PostMapping("/pzz")
	public String login(@RequestParam("username") String username ,
			@RequestParam(name="password") String password ,
			@RequestParam("por")  String x,Map<String, Object> m)
	{
		String page="/login.jsp";
		
		if(x.equals("Login"))
				{
			
			System.out.println(username + " " +  password) ;
			CUser found_user = serviceInf.searchuser(username,password);
			System.out.println("found user is " + found_user);
			if(found_user.getUsername().equals(username))
			{
				m.put("k1", "user details found");
				m.put("existingdetails", found_user);
				
				page= "/start1.jsp";
			}
			else
			{
				page ="/login.jsp";
				m.put("k1", "user details not found");
				m.put("existingdetails",found_user);
			}
			
			
				}

		return page; 	

			}
		
	
	@PostMapping("/lastservlet")
	public String goSlow(@RequestParam("username") String username ,
			@RequestParam(name="pincode") String pincode ,
			@RequestParam("password") String password ,
			@RequestParam("email") String email ,
			@RequestParam("por")  String x,Map<String, Object> m)
	{
		
		String s ="/start1.jsp";
		/*
		 * if(inf != null) m.put("k1","service wired"); else
		 * m.put("k1","serivice not wired");
		 */	
		if(x.equals("getdetails"))
		{
			
			CUser user = serviceInf.getUserDetails(username);
			
			if(user.getPincode() ==0)
			{
				m.put("k1", "user details not found");
				
			}
			else
			{
				m.put("k1", "user details found");
				m.put("existingdetails", user);
			}
			
			
			
		}
		else if(x.equals("update"))
		{
			
			CUser user =new CUser(username, password, email, Integer.parseInt(pincode));
			boolean y = serviceInf.updateUserDetails(user);
			System.out.println("value of y is" + y);
			if(y)
			{
				m.put("k1","details updated");
			}
			else
			{
				m.put("k1","details not updated");
			}
			user.setUsername("");
			user.setPassword("");
			user.setPincode(0);
			user.setEmail("");
			m.put("existingdetails",user );

			
			
		}
		else if(x.equals("insert"))
		{
			
			
			CUser user =new CUser(username, password, email, Integer.parseInt(pincode));
			boolean y = serviceInf.registerUser(user);
			System.out.println("value of y is" + y);
			if(y)
			{
				m.put("k1","inserted");
			}
			else
			{
				m.put("k1","details not added");
			}
			user =new CUser("", "", "", 0);
			
			m.put("existingdetails",user );
			
			
			
		}
		
		else if(x.equals("get users on pincode"))
		{
			
			int pc = Integer.parseInt(pincode);
			List<CUser> users = serviceInf.getUsersBasedOnPincode(pc);
			if(users.size() ==0)
				m.put("k1", "no users found in the pincode");
			else
				m.put("k1", "users found in pincode");
			 m.put("ms", users);
			
			
			
		}
		
		
		
		return s;
		
	}
	
	
	@PostMapping("/ijk")
	public String f1(@ModelAttribute  Rct  x ,Map<String, Object> m)
	{
		m.put("k4",x.getL() *x.getB());
		System.out.println("value of x "+ x.getL());
		return "hi.jsp";
		
	}
	
	
	
	
	
	@PostMapping("/abc")
	public String f1(@RequestParam("q")  int x ,Map<String, Object> m)
	{
		m.put("k1",x*3);
		System.out.println("value of x "+ x);
		return "hi.jsp";
		
	}
	
	@GetMapping("/def")
	public String f2(@RequestParam("q")  int x ,Map<String, Object> m)
	{
		List<Integer> l =new ArrayList<Integer>();
		l.add(x*2);
		l.add(x *3);
		l.add(x *4);
		m.put("k2",l);
		System.out.println("value of x "+ x);
		return "hi.jsp";
		
	}
	
	@PostMapping("/ghi")
	public  String f3(Map<String, Object> m)
	{
		Rct r =new Rct(12,13);
		m.put("k3",r);
		return "hi.jsp";
		
		
	}
	
	
	

}
