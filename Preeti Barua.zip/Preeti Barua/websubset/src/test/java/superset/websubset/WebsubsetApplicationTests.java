package superset.websubset;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsubsetApplicationTests {

	@Test
	void contextLoads() {
	}

}
