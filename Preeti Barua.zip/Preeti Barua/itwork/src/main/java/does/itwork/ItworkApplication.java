package does.itwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("does.itwork,archcodewithspringdb,emp_archodewithspringdb")
@SpringBootApplication
public class ItworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItworkApplication.class, args);
	}

}
