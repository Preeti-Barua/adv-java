package does.itwork;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import emp_archodewithspringdb.Emp;
import emp_archodewithspringdb.ServiceInf;




//sign our controller functions
//wil no longer return response, it will return
//just data..
@RestController 
public class A2 {
	
	@Autowired
	private ServiceInf serviceInf;
	
	
	public A2() {
		if(serviceInf != null) 
		{
			System.out.println("wiered service A2");
		}
		// TODO Auto-generated constructor stub
	}



	@PutMapping("/eau")
	boolean registerUser(@RequestBody Emp user)
	{
		boolean y = serviceInf.registerUser(user);
		return y;
		
		
	}
	
	
	
	@PostMapping("/euu")
	boolean updateUser(@RequestBody Emp user)
	{
		
		boolean y =serviceInf.updateUserDetails(user);
		return y;
		
		
	}
	
	@DeleteMapping("/edu")
	boolean removeUser(@RequestParam("x") String empno)
	{
		boolean y = serviceInf.removeUser(Integer.parseInt(empno));
		return y;		
		
	}
	
	@GetMapping("ems")
	public List<Emp> getUsersBasedOnDeptid(@RequestParam("x") String deptid){
		List<Emp> empl =serviceInf.getUsersBasedOnDeptid(Integer.parseInt(deptid));
				
		return empl;
		
	}
	
	
	
	
	
	@GetMapping("/ess")
	public Emp getUserDetails(@RequestParam("x") String empno)
	{
		Emp user =serviceInf.getUserDetails(Integer.parseInt(empno));
		return user;
		
	}
	
	
	
	@GetMapping("/ehw")
	public String f1()
	{
		return "hello";
		
	}
	
	
	
	

}
