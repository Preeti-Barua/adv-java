package emp_archodewithspringdb;

import java.util.ArrayList;
import java.util.List;

public class ListBasedMockDAOImplementation implements DAOInterface {
	
	private List<Emp> users ;
	
	public ListBasedMockDAOImplementation()
	{
		
		users=new ArrayList<>();
		users.add(new Emp("A",1,400044));
		users.add(new Emp("D",2,400044));
		users.add(new Emp("E",3,400045));
		
	}

	@Override
	public void registerUserInDb(Emp user) throws DuplicateUserException {
		// TODO Auto-generated method stub
		int position = users.indexOf(user);
		if (position != -1)
		{  
			throw new DuplicateUserException("duplicate User found");
			
		}
		users.add(user);
		
	}

	@Override
	public Emp getUserDetailsFromDb(int empno) {
		// TODO Auto-generated method stub
		
		Emp userToFind = new Emp("",empno,0);//think why we did not pass other parameters.
		int pos = users.indexOf(userToFind);
		if(pos != -1)
		{
			
			userToFind = users.get(pos);
			
		}
		
		return userToFind;
	}

	@Override
	public boolean updateDetailsInDb(Emp user) {
		// TODO Auto-generated method stub
		
		boolean updatedStatus = false;
		int pos = users.indexOf(user);
		System.out.println("out u");
		if(pos != -1)
		{
			//think why are we doing this.
			Emp userFromList = users.get(pos);
			System.out.println("in u");
			userFromList.setDeptid(user.getDeptid());
			userFromList.setName(user.getName());
			updatedStatus = true;
				
		}
		
		return updatedStatus;
	}

	@Override
	public boolean removeUserInDb(int empno) {
		// TODO Auto-generated method stub
		boolean deleted = false;
		Emp userToFind = new Emp("",empno,0);//think why we did not pass other parameters.
		int pos = users.indexOf(userToFind);
		if(pos != -1)
		{
			users.remove(pos);
			deleted  =true;
			
		}
		return deleted;
	}

	

	@Override
	public List<Emp> getAllUsersFromDBBasedonDeptid(int deptid) {
		// TODO Auto-generated method stub
		List<Emp> cusers =new ArrayList<Emp>(); //if i change the refernce to users what will happen think
		for(Emp user: users)
		{
			if(user.getDeptid() == deptid) //think why == was used and not .equals.
			{
				cusers.add(user);
			}
			
		}
		
		return cusers;
	}
	
	
	

}
