package emp_archodewithspringdb;

import java.util.List;

public interface DAOInterface {

	void registerUserInDb(Emp user) throws DuplicateUserException;

	Emp getUserDetailsFromDb(int empno);

	boolean updateDetailsInDb(Emp user);

	boolean removeUserInDb(int empno);

	

	List<Emp> getAllUsersFromDBBasedonDeptid(int deptid);

}
