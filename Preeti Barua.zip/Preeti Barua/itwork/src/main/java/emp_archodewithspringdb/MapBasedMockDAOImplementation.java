package emp_archodewithspringdb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapBasedMockDAOImplementation implements DAOInterface {
	
	private Map<String,Emp> users ;
	
	
	public MapBasedMockDAOImplementation()
	{
		
		users=new HashMap<>();
		Emp user =new Emp("A",1,400044);
		users.put(String.valueOf(user.getEmpno()), user);
		user =new Emp("D",2,400044); //why are we writing user = and not Cuser user = ?
		users.put(String.valueOf(user.getEmpno()), user);
		user =new Emp("E",3,400045);		
		users.put(String.valueOf(user.getEmpno()), user);
		
		
		
	}

	@Override
	public void registerUserInDb(Emp user1) throws DuplicateUserException {
		// TODO Auto-generated method stub
		int empno = user1.getEmpno();
		Emp user = users.get(String.valueOf(empno));
		if (user != null)//if key is present, that means it is a duplicate userid.
		{  
			throw new DuplicateUserException("duplicate User found");
			
		}
		users.put(String.valueOf(empno),user1);
		
		
	}

	@Override
	public Emp getUserDetailsFromDb(int empno) {
		// TODO Auto-generated method stub
		
		Emp userToFind = null;//think why we did not pass other parameters.
		userToFind = users.get(String.valueOf(empno));
		if (userToFind == null)
		{  
			userToFind = new Emp("",0,0);
		}
		return userToFind;
	}
	
	
	
	
	

	@Override
	public boolean updateDetailsInDb(Emp user) {
		// TODO Auto-generated method stub
		
		boolean updatedStatus = false;
		Emp cUser = users.get(String.valueOf(user.getEmpno())); //think why we created a new reference cUser here
		//and not used user = users.get(user.getUsername()
		
		if(cUser != null)
		{
			//think why are we doing this.
			cUser.setName(user.getName());
			cUser.setDeptid(user.getDeptid());
			
			updatedStatus = true;
			
		}
		return updatedStatus;
	}

	@Override
	public boolean removeUserInDb(int empno) {
		// TODO Auto-generated method stub
		boolean deleted = false;
		Emp cUser = users.remove(String.valueOf(empno)); //think why we created a new reference cUser here
		//and not used user = users.get(user.getUsername()
		
		if(cUser != null)
		{
				deleted = true;
		
		}
		return deleted;
	}

	@Override
	public List<Emp> getAllUsersFromDBBasedonDeptid(int deptid) {
		// TODO Auto-generated method stub
		List<Emp> cusers = new ArrayList<>();
		for(Emp user: users.values())  //find out what is return type of user.values functions
		{
			if(user.getDeptid() == deptid) //think why == was used and not .equals.
			{
				cusers.add(user);
			}
			
		}
		
		return cusers;
	}
	
	
	

}
