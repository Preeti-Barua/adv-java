package emp_archodewithspringdb;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;



@Repository
public class JDBCImplemntations implements DAOInterface {
	
	@Autowired
	private JdbcTemplate t;
	

	@Override
	public void registerUserInDb(Emp user) throws DuplicateUserException {
		// TODO Auto-generated method stub
		
		String sql =" insert into employee(empname,empid,deptid) values(?,?,?);";
		Object parms[]= {user.getName(),user.getEmpno(),user.getDeptid()};
			try {
				int ra = t.update(sql, parms);		
				
			} catch (DataAccessException e ) {
				
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				DuplicateUserException d =new DuplicateUserException("hey duplicate id");
				throw d;
				
			}
	
		}
		
		
		



	@Override
	public Emp getUserDetailsFromDb(int empid) {
		// TODO Auto-generated method stub
		Emp user =new Emp("",empid, 0);
		
		String sql ="select empname,empid,deptid from employee where empid = ?";
		Object parm[] = {empid};
		BeanPropertyRowMapper<Emp> rm = BeanPropertyRowMapper.newInstance(Emp.class);
		try {
			user = t.queryForObject(sql, parm, rm);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			System.out.println("where codntion failed exception has ocured");
		}		
		
		return user;
	}

	@Override
	public boolean updateDetailsInDb(Emp user) {
		// TODO Auto-generated method stub
		boolean updated = false;
		
		String sql =" update employee set empname = ? ,deptid= ? where empid = ?";
		Object param[]= {user.getName(),user.getDeptid(),user.getEmpno()};
			try {
				int ra = t.update(sql, param);
				if(ra>0)
					updated = true;
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("where codntion failed exception has ocured");
				
			}
				
		return updated;
	}

	@Override
	public boolean removeUserInDb(int empid) {
		// TODO Auto-generated method stub
		boolean updated = false;
		String sql ="delete from   employee   where empid =?";
		Object params[]= {empid };
		try {
			int ra = t.update(sql,params);
			if( ra > 0)
				updated=true;
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("where codntion failed exception has ocured");
						
		}
		return updated;
	
	}

	@Override
	public List<Emp> getAllUsersFromDBBasedonDeptid(int deptid) {
		// TODO Auto-generated method stub
		List<Emp> l=new ArrayList<>();
			
		String sql ="select empname,empid,deptid from employee where deptid = ?";
		Object param[]= {deptid};
		BeanPropertyRowMapper<Emp> rw = BeanPropertyRowMapper.newInstance(Emp.class);
		
		try {
			l = t.query(sql, param,rw);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("where codntion failed exception has ocured");
			
		}
		
		return l;
	}



	

}
