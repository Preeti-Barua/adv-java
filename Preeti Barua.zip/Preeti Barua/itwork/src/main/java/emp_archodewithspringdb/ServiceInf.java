package emp_archodewithspringdb;

import java.util.List;

public interface ServiceInf {

	boolean registerUser(Emp user);

	Emp getUserDetails(int empno);

	boolean updateUserDetails(Emp user);

	boolean removeUser(int empno);



	List<Emp> getUsersBasedOnDeptid(int deptid);

}
