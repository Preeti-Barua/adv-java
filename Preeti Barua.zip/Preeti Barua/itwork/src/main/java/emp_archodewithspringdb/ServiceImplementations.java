package emp_archodewithspringdb;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceImplementations implements ServiceInf {
	
	@Autowired
	private DAOInterface daoInterface;
	
	

	public ServiceImplementations(DAOInterface x) {
		// TODO Auto-generated constructor stub
		System.out.println("service object created A2");
		
		//daoInterface = new ListBasedMockDAOImplementation();
		
		//daoInterface = new MapBasedMockDAOImplementation();

		//daoInterface = new JDBCImplemntation();
//	daoInterface = x;
		
	}



	@Override
	public boolean registerUser(Emp user) {
		// TODO Auto-generated method stub
		
		boolean insertStatus = false;		
		try {
			daoInterface.registerUserInDb(user);
			insertStatus=true;
		} catch (DuplicateUserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insertStatus;
	}



	@Override
	public Emp getUserDetails(int empno) {
		// TODO Auto-generated method stub
		Emp user = daoInterface.getUserDetailsFromDb(empno);
		return user;
	}



	@Override
	public boolean updateUserDetails(Emp user) {
		// TODO Auto-generated method stub
		return daoInterface.updateDetailsInDb(user);
	}



	@Override
	public boolean removeUser(int empno) {
		// TODO Auto-generated method stub
		return daoInterface.removeUserInDb(empno);
	}



	



	@Override
	public List<Emp> getUsersBasedOnDeptid(int deptid) {
		// TODO Auto-generated method stub
		return daoInterface.getAllUsersFromDBBasedonDeptid(deptid);
	}

}
