package archcodeemp;


//ab ye ata h na ha ye srvice layer h jisme service layer interface impl kia h ok run ho rha h na? ha ho rha h ab khush ho na?no no 
//kaha khush abh to vo sb bana hi nahi hbaki controller ban jyega vo bhi
import java.sql.SQLException;
import java.util.List;

public class ServiceLayerImplem implements ServiceInterface{
	
	private DAOInterface daointerface;

	public ServiceLayerImplem() {
		daointerface =new JDBCImplemenEmp();
	}

	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		boolean insertstat=false;
		try {
			daointerface.registerUserinDB(emp);
			insertstat=true;
		} catch (DuplicateEmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insertstat;
	}

	@Override
	public Employee getEmpdetails(int empid)  {
		// TODO Auto-generated method stub
		
			Employee ex=daointerface.getEmpDetailsfromDB(empid);
		
		return ex;
	}

	@Override
	public boolean updateEmpdetails(Employee emp) {
		// TODO Auto-generated method stub
		
		return daointerface.updatEmpDetailinDB(emp);
	}

	@Override
	public boolean removeEmp(int empid) {
		// TODO Auto-generated method stub
			
		return daointerface.deleteEmpinDB(empid);
	}

	@Override
	public List<Employee> getEmpBasedonSalary(double salary) {
		// TODO Auto-generated method stub
		return daointerface.getAllEmployeefromDB(salary);
	}
	

}
