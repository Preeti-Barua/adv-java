package archcodeemp;

import java.sql.SQLException;
import java.util.List;

public interface ServiceInterface {
	
	boolean addEmployee(Employee emp);
	
	Employee getEmpdetails(int empid) ; // if yaha string krdo to paarsing ki need ni ok ok
	
	boolean updateEmpdetails(Employee emp) ;
	
	boolean removeEmp(int empid) ;

	List<Employee> getEmpBasedonSalary(double salary) ;
	
	
	
}
