package archcodeemp;

import java.sql.SQLException;
import java.util.List;

public interface DAOInterface {

	void registerUserinDB(Employee emp) throws  DuplicateEmployeeException;
	
	Employee getEmpDetailsfromDB(int empid) ;
	
	boolean updatEmpDetailinDB(Employee emp) ;
	
	boolean deleteEmpinDB(int empid);
	
	List<Employee> getAllEmployeefromDB(double salary) ;
	
}
