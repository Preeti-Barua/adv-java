package archcodeemp;

import java.sql.SQLException;



public class PresentationLayer {
	
	private ServiceInterface serviceInf;
	
	public PresentationLayer() {
	
		serviceInf=new ServiceLayerImplem();
		// TODO Auto-generated constructor stub
	}

	public void start() throws SQLException {
		// TODO Auto-generated method stub
		
	//	insert();
	//	update();
		delete();
		//getdetails();
		// yaha pe update delete wala bhi method likho n multiselect wala bhi okay 
	}

	private void getdetails() throws SQLException {
		// TODO Auto-generated method stub
		int eid=1;
		
		Employee e=serviceInf.getEmpdetails(eid);
		System.out.println(e);
		
	}
	//kya kru 
	
	private void update()
	{
		Employee e=new Employee(107, "aaskia", 122, 2622.320);
		
		boolean x=serviceInf.updateEmpdetails(e);
		
	}
	private void delete()
	{
       Employee e=new Employee(107, "", 0, 0);
		
		boolean x=serviceInf.removeEmp(e.getEmpid()); 
	}

	private void insert() {
		// TODO Auto-generated method stub
		Employee e=new Employee(107, "kia", 12, 12622.320);
		boolean x=false;
		x=serviceInf.addEmployee(e);
		if(x)
		{
			System.out.println("Insert Successful");
		}
		else
		{
			System.out.println("Not successfull ");
		}
		
		
	}

}
