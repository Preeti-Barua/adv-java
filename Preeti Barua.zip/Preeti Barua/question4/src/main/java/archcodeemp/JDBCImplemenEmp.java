package archcodeemp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JDBCImplemenEmp implements DAOInterface{
	
	Connection con;
	
	public JDBCImplemenEmp() {
		
		String driverName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/test";
		String userid="root";
		String password="root";
		
		try {
			Class.forName(driverName);
			con=DriverManager.getConnection(url, userid, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL COnnection not established");
		}
		
	}

	
	
	
	@Override
	public void registerUserinDB(Employee emp){
		// TODO Auto-generated method stub
		PreparedStatement st=null;
		String sql="insert into employee values(?,?,?,?)";
		
		try {
				st=con.prepareStatement(sql);
				st.setInt(1, emp.getEmpid());
				st.setString(2, emp.getEmpname());
				st.setInt(3, emp.getDeptid());
				st.setDouble(4, emp.getSalary());
				
				int res=st.executeUpdate();
					
			System.out.println("Insert Succeeded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			DuplicateEmployeeException dee=new DuplicateEmployeeException("Duplicate Data");
			
		}
		
		finally {
			try {
				st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("XYZ");
			}
		}
		
		
	}

	@Override
	public Employee getEmpDetailsfromDB(int empid)  {
		// TODO Auto-generated method stub
		
		Employee emp=new Employee(empid, "", 0, 0);
		
		String sql="select empid,empname,deptid,salary from employee where empid=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, empid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				int eid=rs.getInt("empid");
				String ename=rs.getString("empname");
				int did=rs.getInt("deptid");
				double sal=rs.getDouble("salary");
				emp.setDeptid(did);
				emp.setEmpid(eid);
				emp.setEmpname(ename);
				emp.setSalary(sal);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return emp;
	}

	@Override
	public boolean updatEmpDetailinDB(Employee emp)  {
		// TODO Auto-generated method stub
		boolean updated=false;
		String sql="update employee set empname=?,deptid=?,salary=? where empid=?";
		
	
		
			try {

				PreparedStatement st=con.prepareStatement(sql);
				st = con.prepareStatement(sql);
				st.setInt(4, emp.getEmpid());
				st.setString(1, emp.getEmpname());
				st.setInt(2, emp.getDeptid());
				st.setDouble(3, emp.getSalary());
				int x=st.executeUpdate();
				if(x>0)
				{
					System.out.println("Updated");
				}
				else
				{
					System.out.println("Update failedd...");
				}
				
			} 
	
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}


	@Override
	public boolean deleteEmpinDB(int empid) {
		// TODO Auto-generated method stub
		boolean deleted;
		deleted = false;
		String sql="delete from employee where empid=?";
		try {
		
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, empid);
			
			int ra=ps.executeUpdate();
			if(ra>0)
			{
				System.out.println("Deleted");
			}
			else
			{
				System.out.println("Del failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deleted;
	}

	@Override
	public List<Employee> getAllEmployeefromDB(double salary)  {
		// TODO Auto-generated method stub
		List<Employee> e=new ArrayList<>();
		String str="select empid,empname,deptid,salary from employee where salary>?";
		try {
			PreparedStatement ps=con.prepareStatement(str);
			ps.setDouble(1, salary);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Employee em=new Employee();
				em.setDeptid(rs.getInt("deptid"));
				em.setEmpid(rs.getInt("empid"));
				em.setEmpname(rs.getString("empname"));
				em.setSalary(rs.getDouble("salary"));
				e.add(em);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		return e;
	}
	
	

}
