package archcodebank;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class JDBCImplement implements DAOInterface{

Connection con;
	
	public JDBCImplement() {
		//wait back krna 
		String driverName="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/test";
		String userid="root";
		String password="root";
		
		try {
			Class.forName(driverName);
			con=DriverManager.getConnection(url, userid, password);
			System.out.println("Connection established");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL COnnection not established");
		}
		
	}	
	@Override
	public boolean loginFunction(int accno, int pin) {
		// TODO Auto-generated method stub
		boolean x=false;
		BankDetails b=new BankDetails(accno, pin, 0, false, "");
		String st="select accno,pin,balance from BankDetails where accno=? and pin=?";
		try {
			
			PreparedStatement ps=con.prepareStatement(st); 
				ps.setInt(1, b.getAccno());
				ps.setInt(2, b.getPin());
				ResultSet rs=ps.executeQuery();
				if(rs.next())
					
				{
					int ano=rs.getInt("accno");
					int pinno=rs.getInt("pin"); 
					if(ano==b.getAccno() )
					{
						if(pinno==b.getPin())
								{
									x=true;
								}
					}
				}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		return x;
	}

	@Override
	public int viewBalnce(int accno) {
		// TODO Auto-generated method stub
		BankDetails b=new BankDetails(accno, 0, 0, false, "");//(int accno, int pin, int balance, boolean blocked, String branchname)
		String st="select balance from BankDetails where accno=?";
		int balance=0;
		try {
			PreparedStatement ps=con.prepareStatement(st);
			ps.setInt(1, b.getAccno());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				balance=rs.getInt("balance");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balance;
	}

	@Override
	public boolean withdraw(int accno) {
		// TODO Auto-generated method stub
		BankDetails b=new BankDetails(accno, 0, 0, false, "");//(int accno, int pin, int balance, boolean blocked, String branchname)
		String st="select balance from BankDetails where accno=?";
		boolean x=false;
		int withdrawlamount=1000;
	
		try {
			PreparedStatement ps=con.prepareStatement(st);
			ps.setInt(1, b.getAccno());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				int bal=rs.getInt("balance");
		
				{
			            bal=bal-withdrawlamount;
			         
			         	x= true;
			    }
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return x;
	}

	@Override
	public boolean deposit(int accno) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		BankDetails b=new BankDetails(accno, 0, 0, false, "");//(int accno, int pin, int balance, boolean blocked, String branchname)
		String st="select balance from BankDetails where accno=?";
		boolean x=false;
		int depositamount=1000;
		int bal;
		try {
			PreparedStatement ps=con.prepareStatement(st);
			ps.setInt(1, b.getBalance());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				bal=rs.getInt("balance");
				 String st1="update Bankdetails set balance=?+?"  ;
			     PreparedStatement ps1=con.prepareStatement(st1);
			     ps1.setInt(1, bal);
			     ps1.setInt(2, depositamount);
			     int r=ps1.executeUpdate();
			     if(r>0)
			     { 	x= true;}
			   
			}
		    //    bal=bal+depositamount;
		    
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		return x;
	}

	@Override
	public boolean updateBlockstatus(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<BankDetails> showDetailsms(boolean blocked) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBlockaAccno(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUnblockgofUsers(boolean blocked) {
		// TODO Auto-generated method stub
		return false;
	}

}
