package archcodebank;

public class BankDetails {
	
	private int accno;
	private int pin;
	private int balance;
	private boolean blocked;
	private String branchname;
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public int getAccno() {
		return accno;
	}
	public int getPin() {
		return pin;
	}
	public int getBalance() {
		return balance;
	}
	public boolean isBlocked() {
		return blocked;
	}
	public String getBranchname() {
		return branchname;
	}
	@Override
	public String toString() {
		return "BankDetails [accno=" + accno + ", pin=" + pin + ", balance=" + balance + ", blocked=" + blocked
				+ ", branchname=" + branchname + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accno;
		result = prime * result + balance;
		result = prime * result + (blocked ? 1231 : 1237);
		result = prime * result + ((branchname == null) ? 0 : branchname.hashCode());
		result = prime * result + pin;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof BankDetails)) {
			return false;
		}
		BankDetails other = (BankDetails) obj;
		if (accno != other.accno) {
			return false;
		}
		if (balance != other.balance) {
			return false;
		}
		if (blocked != other.blocked) {
			return false;
		}
		if (branchname == null) {
			if (other.branchname != null) {
				return false;
			}
		} else if (!branchname.equals(other.branchname)) {
			return false;
		}
		if (pin != other.pin) {
			return false;
		}
		return true;
	}
	
	public BankDetails() {
		
		// TODO Auto-generated constructor stub
	}
	public BankDetails(int accno, int pin, int balance, boolean blocked, String branchname) {
		
		this.accno = accno;
		this.pin = pin;
		this.balance = balance;
		this.blocked = blocked;
		this.branchname = branchname;
	}
	
	
	
}
