package archcodebank;

public class TestArchitecture {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PresentationLayer p=new PresentationLayer(); // yha se presenation layer ka obj n uska runcode wla method call kia
		p.runcode();
		

	}

}
