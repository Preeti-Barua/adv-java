package archcodebank;

public class PresentationLayer {

	ServiceInterface si; // service interface ka ref create kia usko initialise kia hume servicelayerimp class sse
	
	// ek diagram tha yaad h ha yad h smjh a rha hoga thora thora ha bs code smjhne ka try kr rhe
	public PresentationLayer() {
		si=new ServiceLayerImpl();
		// TODO Auto-generated constructor stub
	}
	public void runcode() {
		// TODO Auto-generated method stub
			
		// loginsuccessorfail(); 
		//viewaccbalance();
	//	withdrawl();
		deposit();
		
	}
	private void viewaccbalance() {
		// TODO Auto-generated method stub
		int x=102332;
		int z=si.viewBalnce(x);
		if(z==0)
		{
			System.out.println("No account found with this accno");
		}
		else
		{
			System.out.println("Balance  for accno "+x+"  is " +z);
		}
		
	}
	private void withdrawl() {
		// TODO Auto-generated method stub
		
		boolean x=si.withdraw(102332);
		if(x==true)
		{
			System.out.println("Withdrawal Successful");
		}
		else
		{
			System.out.println("Withdrawal Failed"); // smjh aya? dekho pehle 2 interface bnaya h
		}
		
	}
	
	public void deposit()
	{
		boolean x=si.deposit(102332);
		if(x==true)
		{
			System.out.println("deposit Successful");
		}
		else
		{
			System.out.println("deposit Failed"); // smjh aya? dekho pehle 2 interface bnaya h
		}
	}
	
	private void loginsuccessorfail() {
		// TODO Auto-generated method stub
		
		boolean x=si.loginFunction(1234, 123);
		if(x)
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login Failed"); // smjh aya? dekho pehle 2 interface bnaya h
		}
		
	}
	


}
