package archcodebank;

import java.util.List;

public interface ServiceInterface {
	
	boolean loginFunction(int accno,int pin);
	
	int viewBalnce(int accno);
	
	boolean withdraw(int accno);
	
	boolean deposit (int accno);

	boolean updateBlockstatus(int accno);
	
	List<BankDetails> showDetailsms(boolean blocked);
	
	boolean updateBlockaAccno(int accno);
	
	boolean updateUnblockgofUsers(boolean blocked);
	
}
