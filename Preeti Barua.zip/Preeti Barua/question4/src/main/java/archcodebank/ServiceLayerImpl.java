package archcodebank;

import java.util.List;

public class ServiceLayerImpl implements ServiceInterface{

	DAOInterface di; // service imp mai hume dao interface ka ref create kia h . n isko initailse kia h jdbc impl class se	
	//again back okay go on..
	public ServiceLayerImpl() {
	di=new JDBCImplement();
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean loginFunction(int accno, int pin) {
		// TODO Auto-generated method stub
		
		boolean x=di.loginFunction(accno, pin);
		
		return x;
	}

	@Override
	public int viewBalnce(int accno) {
		// TODO Auto-generated method stub
		return di.viewBalnce(accno);
	}

	@Override
	public boolean withdraw(int accno) {
		// TODO Auto-generated method stub
		return di.withdraw(accno);
	}

	@Override
	public boolean deposit(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateBlockstatus(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<BankDetails> showDetailsms(boolean blocked) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBlockaAccno(int accno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUnblockgofUsers(boolean blocked) {
		// TODO Auto-generated method stub
		return false;
	}

}
