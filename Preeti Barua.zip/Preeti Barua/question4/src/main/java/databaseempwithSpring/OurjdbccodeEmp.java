package databaseempwithSpring;
import java.util.ArrayList;  
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class OurjdbccodeEmp {

	//controller kaise paste kru new package? 4a kroo bs paste yaha only archcode wala package

// 4b question h ye haa! sorry bana h par run nahi ho rha h isi project m paste kru? 4a wala nahaarchcode of emp ko issme ddaalo
	//is project mai
	// java resource ke package mai q show ni kr rha kch? ha voi bol rhe update maven krne k bde asa hi hota h ki s
	private JdbcTemplate t;

	@Autowired
	public void setT(JdbcTemplate t) {
		System.out.println("JDbc template wired");
		this.t = t;
	}
	
	public void insert()
	{
		Employee x =new Employee(106,"sheena",187,56788); //assume this
		//came from service..
		String sql ="insert into Employee( empid,empname,deptid,salary) values (?,?,?,?)";
		
		Object[] array= {x.getEmpid(),x.getEmpname(),x.getDeptid(),x.getSalary()};
		
		int row = t.update(sql,array);
		
		

		
		
		
		
	}
	// suno dependency add kroo ye nhi h assignmnet folder h na starting m wahi sb h
	public void singleselect()
	{
		
		Employee x =null;
		String username="sheena";
		String sql ="select empid,empname,deptid,salary from Employee  where empname=?";
		Object[] params = { username };
		BeanPropertyRowMapper<Employee>
		pqr =new BeanPropertyRowMapper<Employee>(Employee.class);
		try {
			 x = t.queryForObject(sql, params,pqr);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			x=new Employee(0,"", 0, 0);
		}
		System.out.println("results are " + x.getSalary());
		
		
		
		
		
	}

	public void multiSelect() {
		// TODO Auto-generated method stub
		List<Employee> l =new ArrayList<>();
		int salary=500;
		String sql ="select empid,empname,deptid,salary from Employee  where salary>?";
		Object[]  params= {salary};
		BeanPropertyRowMapper<Employee>
		pqr =new BeanPropertyRowMapper<Employee>(Employee.class);
		try {
			 l = t.query(sql, params,pqr);
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		for (Employee el : l) {
			System.out.println(el);
		}
	}
	
	
	
	
	
	
}


