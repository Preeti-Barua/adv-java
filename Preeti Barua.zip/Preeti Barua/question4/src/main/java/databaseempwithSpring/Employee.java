package databaseempwithSpring;

public class Employee {

	private int empid;
	public Employee(int empid, String empname, int deptid, double salary) {
		
		this.empid = empid;
		this.empname = empname;
		this.deptid = deptid;
		this.salary = salary;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	private String empname;
	private int deptid;
	private double salary;
	public int getEmpid() {
		return empid;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", deptid=" + deptid + ", salary=" + salary + "]";
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + deptid;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Employee)) {
			return false;
		}
		Employee other = (Employee) obj;
		if (deptid != other.deptid) {
			return false;
		}
		return true;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
