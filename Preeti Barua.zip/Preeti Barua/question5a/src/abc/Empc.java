package abc;

import java.util.List; 

import javax.servlet.http.HttpServletRequest;

import archcodeemp.Employee;
import archcodeemp.ServiceInterface;



public class Empc {
	
		
		private ServiceInterface serviceInf;
		
		public Empc()
		{
			serviceInf = new archcodeemp.ServiceLayerImplem();
		}
		

		public String learntodopoc(HttpServletRequest request) {
			// TODO Auto-generated method stub
			String page="/startemp.jsp";
			request.setAttribute("k1","ok one day i have to do select here");
			String userid = request.getParameter("empname");
			Employee user = serviceInf.getEmpdetails(Integer.parseInt(userid)); 
			
			if(user.getDeptid()==0)
			{
				request.setAttribute("k1", "user details not found");
				
			}
			else
			{
				request.setAttribute("k1", "user details found");
				request.setAttribute("existingdetails", user);
			}
			
			
			return page;
		}

		public String updateEmpdetails(HttpServletRequest request) {
			// TODO Auto-generated method stub
			String page="/startemp.jsp";
			String eid = request.getParameter("employeeid");
			String ename= request.getParameter("employeename");
			String deptid= request.getParameter("deptid");
			String salary = request.getParameter("salary");
		
			// you must know service is required cuser object.
			Employee x =new Employee(Integer.parseInt(eid),ename,Integer.parseInt(deptid),Double.parseDouble(salary));
			boolean y = serviceInf.updateEmpdetails(x);
			System.out.println("value of y is" + y);
			if(y)
			{
				request.setAttribute("k1","details updated");
			}
			else
			{
				request.setAttribute("k1","details not updated");
			}
		
			
			x.setEmpid(0);
			x.setEmpname(" ");
			x.setDeptid(0);
			x.setSalary(0);
			
			request.setAttribute("existingdetails",x );

			
			
			
			
			
			return page;
		}


		private void setEmpname() {
			// TODO Auto-generated method stub
			
		}


		public String getEmpBasedonSalary(HttpServletRequest request) {
			// TODO Auto-generated method stub
			
			String page="/startemp.jsp";
			int deptid = Integer.parseInt(request.getParameter("deptid"));
			List<Employee> users = serviceInf.getEmpBasedonSalary( deptid);
			if(users.size() ==0)
				request.setAttribute("k1", "no users found in the deptid");
			else
				request.setAttribute("k1", "users found in pincode");
			request.setAttribute("ms", users);
			return page;
		}


		public String adduser(HttpServletRequest request) {
			// TODO Auto-generated method stub
			
			String page="/startemp.jsp";
			String eid = request.getParameter("employeeid");
			String ename = request.getParameter("employeename");
			String deptid = request.getParameter("deptid");
			String salary = request.getParameter("salary");
			// you must know service is required cuser object.
			Employee x =new Employee(Integer.parseInt(eid),ename,Integer.parseInt(deptid),Double.parseDouble(salary));
			boolean y = serviceInf.addEmployee(x);
			System.out.println("value of y is" + y);
			if(y)
			{
				request.setAttribute("k1","inserted");
			}
			else
			{
				request.setAttribute("k1","details not added");
			}
			x =new Employee(0, "", 0, 0);
			
			request.setAttribute("existingdetails",x );
			return page;
			
		}

	}
