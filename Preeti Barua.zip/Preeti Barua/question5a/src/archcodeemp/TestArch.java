package archcodeemp;

import java.sql.SQLException;

public class TestArch {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		PresentationLayer p=new PresentationLayer();
		p.start();

	}

}
//suno naa haa ye archcode banane ka first step kya hai? Presentation ? maine pehle dao n then service baya tha achha to bottom se
//start krna h ? maine kia h syd presen se start hota h