package e;

import org.springframework.boot.SpringApplication; 
import org.springframework.boot.autoconfigure.SpringBootApplication;


	


@SpringBootApplication
public class OnlywebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlywebserviceApplication.class, args);
	}

}


	


