package emp.controller;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import emp.models.Employee;
import emp.models.EmpCResult;
import emp.services.EmpService;
import emp.services.EmployeeServiceImplementation;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
public class EmpController {

		
		@Autowired
		private EmpService s;
		
		@GetMapping("/a")
		public String f1()
		{
			return "who asked us to be optimistic";
		}
		
		
		@PutMapping("/add")
		public EmpCResult addEmp(@RequestBody Employee c)
		{
			/*
			
			System.out.println("insert  is" + c);
			CResult cr =new CResult(1,null,"insttest");
			return cr;
			
			*/
			System.out.println("inside add");
			EmpCResult x = s.addEmp(c);
			return x;
			
			
		}
		
		
		@PostMapping("/upt")
		public EmpCResult updateAcc(@RequestBody Employee c) {
		
			/*
			System.out.println("update  is" + c);
			CResult cr =new CResult(1,null,"upttest");
			return cr;
	*/
			EmpCResult x = s.updateEmp(c);
			return x;
			
			
		}
		
		@DeleteMapping("/remove")
		public EmpCResult removeAcc(@RequestParam("x") int empid) {
			
			/*
			System.out.println("remove  is" + accno);
			CResult cr =new CResult(1,null,"removtest");
			return cr;
			
			*/
			
			EmpCResult x = s.removeEmp(empid);
			return x;
		}
		
		@GetMapping("/ss")
		public EmpCResult getEmpSS(@RequestParam("x") int empid)
		{
			
			/*
			System.out.println("single select  is" + accno);
			CResult cr =new CResult(1,new Acc(1, "pqr", 20),"singletest");
			return cr;
			
			*/
			EmpCResult x = s.getEmpSS(empid);
			return x;
		
			
		}
		
		@GetMapping("/ms")
		public List<Employee> getAllDetails(){
			
			/*
			
			List<Acc> l =new ArrayList<Acc>();
			l.add(new Acc(10,"A",3));
			return l;
			
			*/
			List<Employee> l =s.getAllDetails();
			return l;
			
			
		}
		
		@GetMapping("/msoc")
		public List<Employee> getAllDetailsOnSalary(@RequestParam("x") int salary){
			
			List<Employee> l = s.getAllDetailsOnSalary(salary);
			return l;
			/*
			System.out.println("balance is " + balance);
			List<Acc> l =new ArrayList<Acc>();
			l.add(new Acc(20,"B",4));
			return l;
			
			*/
			
			
		}
		
		
		
		
		
		
		
		
		
}
